import { useMemo } from 'react';
import MovieShow from './MovieShow';

const MovieList = ({movies}) => {
  const renderedMovies = useMemo(() => {
    return movies.map((movie) => {
      return <MovieShow key={movie.id} movie={movie} />;
    });
  }, [movies]);

  return (
    <div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
         {renderedMovies}  
      </div>
    </div>
  )
}

export default MovieList
