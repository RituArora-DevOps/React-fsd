import './App.css';
import SearchedImages from './components/SearchedImages';

function App() {
  return (
    <div>
      <SearchedImages />
    </div>
  );
}

export default App;
